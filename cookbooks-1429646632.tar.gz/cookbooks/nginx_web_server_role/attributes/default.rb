default['web']['web_server_type'] = "nginx"
default['web']["config_path"] = "/etc/nginx/conf.d/default.conf"
default['web']["server_port"] = "80"
default['web']["server_interface"] = "0.0.0.0"
