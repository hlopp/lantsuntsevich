default['web']['web_server_type'] = "apache"
default['web']["config_path"] = "/etc/apache2/httpd.conf"
default['web']["server_port"] = "80"
default['web']["server_interface"] = "0.0.0.0"
