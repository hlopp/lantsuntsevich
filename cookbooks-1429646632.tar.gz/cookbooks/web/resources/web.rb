#resource
actions :install, :setup_web_server, :stop, :start, :restart, :reload
default_action :install

provides :web
